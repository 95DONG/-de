import request from '@/utils/request'
export const getCityInfo = (params) => {
  return request({
    method: 'GET',
    url: '/houses',
    params
  })
}
