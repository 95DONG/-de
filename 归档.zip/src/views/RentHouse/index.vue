<template>
  <div>
    <!-- 导航栏 -->
    <van-nav-bar title="发布房源" left-arrow @click-left="onClickLeft" />
    <div class="main">
      <van-cell class="message" title="房源信息" />
      <van-cell
        title="小区名称"
        value="请输入小区名称"
        is-link
        @click="isNounShow = true"
      />
      <van-field placeholder="请输入租金/月" label="租 金">
        <template #button>
          <span>¥/月</span>
        </template>
      </van-field>
      <van-field placeholder="请输入建筑面积" label="建筑面积">
        <template #button>
          <span>m²</span>
        </template>
      </van-field>
      <van-cell title="户型" value="请选择" is-link />
      <van-cell title="所在楼层" value="请选择" is-link />
      <van-cell title="朝向" :border="false" value="请选择" is-link />
      <van-cell title="房屋标题" />
      <van-cell title="房屋标题" />
      <!-- 小区名称弹出 -->
      <van-popup
        is-link
        position="bottom"
        v-model="isNounShow"
        style="height: 100%"
      >
        <form action="/">
          <van-search
            v-model="value"
            show-action
            placeholder="请输入搜索关键词"
            @search="onSearch"
            @cancel="onCancel"
          />
        </form>
      </van-popup>
      <!-- 户型弹出 -->
      <van-popup
        is-link
        position="bottom"
        v-model="isNounShow"
        style="height: 40%"
      >
        <van-picker
          title="标题"
          show-toolbar
          :columns="columns"
        />
      </van-popup>
    </div>
    <!-- 底部按钮 -->
    <div class="btn">
      <van-button square class="left" type="default">取消</van-button>
      <van-button square class="right" type="primary">确认</van-button>
    </div>
  </div>
</template>

<script>
export default {
  created () { },
  data () {
    return {
      isNounShow: false, // 小区名称弹出层显示
      value: '',
      // text: '租金', // 租金数据
      // text1: '面积', // 面积数据
      columns: ['杭州', '宁波', '温州', '绍兴', '湖州', '嘉兴', '金华', '衢州'] // 户型选择数据
    }
  },
  methods: {
    // 导航点击返回按钮
    onClickLeft () {
      this.$router.back()
    },
    onSearch (val) {
      this.toast(val)
    },
    onCancel () {
      this.isNounShow = false
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
.main {
  background-color: rgb(239, 235, 235);
  // height: 100vh;
  overflow: auto;
}
//导航栏样式
/deep/ .van-nav-bar__content {
  background-color: rgb(88, 182, 127);
}
// 底部按钮样式
.btn {
  position: fixed;
  bottom: 0;
  .left {
    width: 375px;
    color: rgb(88, 182, 127);
  }
  .right {
    width: 375px;
  }
}
// 房源信息样式
.message {
  color: rgb(88, 182, 127);
}
</style>
